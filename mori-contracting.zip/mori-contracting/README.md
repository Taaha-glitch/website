# Mori Contracting Inc. Website

Professional website for Mori Contracting Inc. — fully static, hosted free on GitHub Pages.

---

## 📁 File Structure

```
mori-contracting/
├── index.html          ← Main website file
├── css/
│   └── style.css       ← All styling
├── js/
│   └── main.js         ← Interactivity (nav, forms, animations)
├── images/             ← PUT YOUR PHOTOS HERE
│   ├── about.jpg       ← Your "About" section photo
│   ├── photo1.jpg      ← Gallery photo 1
│   ├── photo2.jpg      ← Gallery photo 2
│   ├── photo3.jpg      ← Gallery photo 3
│   ├── photo4.jpg      ← Gallery photo 4
│   ├── photo5.jpg      ← Gallery photo 5
│   └── photo6.jpg      ← Gallery photo 6
└── README.md
```

---

## 🚀 How to Host on GitHub (Free)

1. Go to https://github.com and sign up for free.
2. Create a new **Public** repository (e.g. `moricontracting`).
3. On the repo page, click **uploading an existing file** and drag in `index.html`, the `css/` folder, the `js/` folder, and the `images/` folder. Click **Commit changes**.
4. Go to **Settings → Pages**. Under "Source", select **Deploy from a branch**, branch `main`, folder `/ (root)`. Click **Save**.
5. After 1–2 minutes your site is live at `https://YOUR-USERNAME.github.io/moricontracting/`.

---

## 📷 How to Add/Update Photos

From GitHub (no software needed): open the `images/` folder in your repo → **Add file → Upload files** → upload a photo named exactly `photo1.jpg` (or `photo2.jpg`, `about.jpg`, etc.) → **Commit changes**. The site updates automatically.

You can do this any time — today, next month, whenever — and it never requires touching any code.

Photo tips: JPG works best; landscape photos look best in the gallery; `about.jpg` looks best as a portrait photo.

---

## 📧 How to Activate the Quote Form (Free)

1. Go to https://formspree.io and sign up free.
2. Create a new form and enter the email you want quotes sent to.
3. Copy the Form ID (e.g. `xpzgkwqr`).
4. Open `index.html`, find `action="https://formspree.io/f/YOUR_FORM_ID"`, and replace `YOUR_FORM_ID` with your real ID.
5. Save and re-upload `index.html` to GitHub.

Every submission — including which services were checked — will land straight in that inbox.

---

## ✏️ How to Edit Text / Contact Info

Open `index.html` in any text editor and search for the phone number, email, or address to update them.

---

## 🌐 Custom Domain (Optional, ~$15/year)

Buy a domain at Namecheap or GoDaddy, then follow GitHub's guide: https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site
